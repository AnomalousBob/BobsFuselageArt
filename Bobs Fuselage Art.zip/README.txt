Thank you for downloading my fuselage art mod! This is myy first released KSP mod.
To install, simply copy the folder into your GameData folder.

Conformal Decals and B9 Part Switch are required.